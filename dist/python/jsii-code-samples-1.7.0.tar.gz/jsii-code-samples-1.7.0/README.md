# jsii-code-samples [![NPM](https://img.shields.io/npm/v/jsii-code-samples)](https://www.npmjs.com/package/jsii-code-samples) [![PyPI](https://img.shields.io/pypi/v/aws-jsiisamples.jsii-code-samples)](https://pypi.org/project/aws-jsiisamples.jsii-code-samples/) [![Maven](https://img.shields.io/maven-central/v/software.aws.jsiisamples.jsii/jsii-code-samples)](https://search.maven.org/artifact/software.aws.jsiisamples.jsii/jsii-code-samples) [![NuGet](https://img.shields.io/nuget/v/AWSSamples.Jsii)](https://www.nuget.org/packages/AWSSamples.Jsii/)

> An example jsii package authored in TypeScript that gets published as GitHub packages for Node.js, Python, Java and dotnet.

## License

This library is licensed under the MIT-0 License. See the LICENSE file.
